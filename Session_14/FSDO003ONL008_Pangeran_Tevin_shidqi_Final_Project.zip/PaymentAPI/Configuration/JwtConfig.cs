namespace PaymentAPI.Configuration
{
    public class JwtConfig
    {
        public string Secret {get; set;}
    }
}