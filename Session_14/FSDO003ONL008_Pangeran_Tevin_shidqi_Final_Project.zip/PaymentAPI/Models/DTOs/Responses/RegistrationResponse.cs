using PaymentAPI.Configuration;

namespace PaymentAPI.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}