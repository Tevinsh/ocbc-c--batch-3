Nama : Pangeran Tevin Shidqi
No Peserta:FSDO003ONL008
Link Github:https://github.com/Tevinsh/ocbc-c--batch-3.git
Assignment1
Panduan Penggunaan Aplikasi:
1. buka terminal didalam folder Assignment1
2. Jalankan perintah "mcs Assignment1.cs -out:Assignment1 && mono Assignment1"
3. pilih menu sesuai daftar menu
4. Lakukan instruksi sesuai pesan yang ada diterminal