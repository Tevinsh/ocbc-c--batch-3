Nama : Pangeran Tevin Shidqi
Nama : Pangeran Tevin Shidqi
No Peserta:FSDO003ONL008
Assignment 2
Panduan restore SQL:
file .sql di dump menggunakan dbeaver dan mysql
1. buka dbeaver lalu buat database baru dengan nama db_office
2. di menu database navigator klik kanan pada db_office >> tools >> restore database
3. masukkan file .sql dan lakukan restore database.
