﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sesi7_Form1
{
    
    public partial class LoginForm : Form
    {
        Config db = new Config();
        public LoginForm()
        {
            InitializeComponent();

            db.Connect("userdata");
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            db.ExecuteSelect("SELECT * FROM user_info where username='" + Uname_field.Text + "' and password='" + Password_field.Text + "';");

            if (db.Count() == 1)
            {
                MessageBox.Show("Success You will Login as " + db.Results(0, "names"));
            }
            else
            {
                MessageBox.Show("Wrong username and password combination");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();       
            }
        }
}
