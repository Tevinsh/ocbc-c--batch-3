﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sesi7_Form1
{
    public partial class Register : Form
    {
        Config db = new Config();
        public Register()
        {
            InitializeComponent();
            db.Connect("userdata");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                db.Execute("INSERT INTO user_info (names, username, password) VALUES ('" + Name_field.Text + "','" + Uname_field.Text + "','" + Password_field.Text + "');");
                MessageBox.Show("Sukses mendaftar! welcome to the club " + Name_field.Text);
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
            

            this.Close();
        }
    }
}
