﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmptyApi.Controllers
{
    public class TestController : ApiController
    {
        // GET api/<controller>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "satu", "dua" };
        }

        // GET api/<controller>/5
        [HttpGet]
        public string Get(int id)
        {
            int bilangan = id;
            int result = 1;
            while (id != 1)
            {
                result *= id;
                id--;

            }
            return "faktorial dari "+bilangan+" = "+result;
        }

        // POST api/<controller>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<controller>/5
        [HttpPut]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        [HttpDelete]
        public void Delete(int id)
        {
        }
    }
}